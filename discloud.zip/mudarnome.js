const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mudarnome')
        .setDescription('Muda seu apelido mantendo seus troféus.')
        .addStringOption(option => 
            option.setName('novonome')
                .setDescription('O novo nome (Ex: Teofilo)')
                .setRequired(true)),

    async execute(i) {
        const novoNomeBase = i.options.getString('novonome');
        const membro = i.member;
        const apelidoAtual = membro.displayName;

        // --- LÓGICA DOS TROFÉUS ---
        // Procura pelo caractere "|" e pega tudo o que vem depois dele
        let parteDosTrofeus = "";
        if (apelidoAtual.includes('|')) {
            // Divide o nome no "|", pega a segunda parte e limpa espaços
            parteDosTrofeus = " | " + apelidoAtual.split('|')[1].trim();
        }

        // Monta o apelido final: Novo Nome + a parte guardada
        const apelidoFinal = `${novoNomeBase}${parteDosTrofeus}`;

        // --- VALIDAÇÃO DE TAMANHO ---
        if (apelidoFinal.length > 32) {
            return i.reply({ 
                content: `❌ O nome com os troféus ficaria com **${apelidoFinal.length}** letras. O limite é 32. Tente um nome menor!`, 
                ephemeral: true 
            });
        }

        try {
            // Verifica permissão do bot
            if (!i.guild.members.me.permissions.has('ManageNicknames')) {
                return i.reply({ content: "❌ Eu não tenho permissão de 'Gerenciar Apelidos'.", ephemeral: true });
            }

            await membro.setNickname(apelidoFinal);
            await i.reply({ 
                content: `✅ Nome alterado! De **${apelidoAtual}** para **${apelidoFinal}**`, 
                ephemeral: true 
            });
        } catch (error) {
            console.error(error);
            await i.reply({ 
                content: "❌ Erro: Não consigo mudar seu nome. (Hierarquia de cargos ou você é o Dono).", 
                ephemeral: true 
            });
        }
    },
};