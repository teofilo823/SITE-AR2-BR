const { GoogleGenerativeAI } = require("@google/generative-ai");
const genAI = new GoogleGenerativeAI(process.env.GEMINI_KEY);

const CHATS_PERMITIDOS = ["1306339337084080231", "1306341776281440417", "1473775401451913348"];
const CHAT_PRINCIPAL = "1306339337084080231";
const maldicoes = new Map();

module.exports = (client) => {
    client.on('messageCreate', async (message) => {
        // Ignora bots e mensagens fora dos chats permitidos
        if (message.author.bot || !CHATS_PERMITIDOS.includes(message.channel.id)) return;

        const mencaoBot = message.mentions.has(client.user);
        const eResposta = message.reference && (await message.channel.messages.fetch(message.reference.messageId)).author.id === client.user.id;
        
        // Chance aleatória: 5% no chat principal, 2% nos outros
        const chanceBase = message.channel.id === CHAT_PRINCIPAL ? 0.05 : 0.02;
        const falarSozinho = Math.random() < chanceBase;
        const amaldicoado = maldicoes.has(message.author.id);

        // Só continua se: for marcado, for resposta, chance aleatória ou se o gajo estiver amaldiçoado
        if (!mencaoBot && !eResposta && !falarSozinho && !amaldicoado) return;

        // --- SISTEMA DE MALDIÇÃO (1% de chance ao interagir) ---
        if (Math.random() < 0.01 && !amaldicoado) {
            maldicoes.set(message.author.id, true);
            setTimeout(() => maldicoes.delete(message.author.id), 15 * 60000); // 15 minutos
            return message.reply("⚡ **MALDIÇÃO ATIVADA!** Vou-te perseguir e zoar todas as tuas mensagens nos próximos 15 minutos, lenda. Prepara-te.");
        }

        try {
            await message.channel.sendTyping();

            const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
            
            // Personalidade
            const instrucoes = `És o "Bot AR2 Brasil", uma IA sarcástica, zoeira e mestre no jogo Apocalypse Rising 2. 
            - O teu objetivo é dar dicas de jogo (onde achar loot como AUG, FAL, etc) mas sempre com um tom de gozo.
            - Se o user for noob, podes chamar-lhe "free kill" ou dizer que ele morre para zumbis.
            - Se estiver amaldiçoado (estás a zoar o gajo sem parar), sê mais rude e engraçado.
            - Responde de forma curta, usa gírias brasileiras (ex: "é mole", "tá maluco", "lenda").
            - Não sejas um robô certinho, podes mandar a pessoa ir lootear o Ash se ela fizer perguntas burras.`;

            let promptParts = [{ text: instrucoes }, { text: `Mensagem de ${message.author.username}: ${message.content}` }];

            // --- LÓGICA DE IMAGEM ---
            if (message.attachments.size > 0) {
                const imagem = message.attachments.first();
                if (imagem.contentType?.startsWith('image/')) {
                    const imgResp = await fetch(imagem.url);
                    const imgBuffer = await imgResp.arrayBuffer();
                    promptParts.push({
                        inlineData: {
                            data: Buffer.from(imgBuffer).toString("base64"),
                            mimeType: imagem.contentType
                        }
                    });
                }
            }

            const result = await model.generateContent(promptParts);
            const response = await result.response;
            let texto = response.text();

            // Garante que a resposta não é vazia
            if (!texto) return;

            message.reply(texto.slice(0, 2000));

        } catch (error) {
            console.error("[IA ERRO]", error);
            // O teu sistema de erro global no index.js tratará de enviar para o webhook se isto crashar
        }
    });
};